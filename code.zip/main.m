clear all; close all; clc;

%% add paths and start timer
addpath('./libRIRGenerator/');
addpath('./auxiliary_methods/');
start_sim = tic;
seed = 4;                                  % seed of pseudo random values
path_result_files = './results/';
write_output = true;


%% defining room, microphones and sources
room_dim = [7.0, 5.0, 2.75];                % Room dimensions in m 
sound_vel = 340.5;                          % Speed of sound in m/s  
rt = .2;                                    % RT60 in s  
order = 0;                                  % Reflection order  
mtype = 'omnidirectional';                  % Type of microphone 
snr = 10;                                   % Signal to Noise ratio in dB

num_mics = 6;                               % Number of microphones 
mic_dist = 0.042;                           % Microphone distance in m  
mic_center = [3.5, 3.0, 1.7];               % Position of microphone center in m 

source_pos = [1.5, 4.0, 1.7];               % Source position in m  
%source_pos = [3.5, 3.0, 1.7];
%path_source_file = './soundfiles/female2_16kHz.wav';  % Source Signal  
path_source_file = 'wgn';                    


%% checking if specifications are valid
disp('1) Initialization')

if ~exist(path_result_files)
    mkdir(path_result_files);
end

%% creating room and propagating signals
disp('1.1) Creating room')
room.room_dim = room_dim;     
room.sound_vel = sound_vel;   
room.rt = rt;                 
room.order = order;           
room.snr = snr;               
room.crit_dist = 0.1 * sqrt(prod(room.room_dim) / (pi * room.rt));          % from Aigner - Acoustics Source Separation in Convolutive Environments [p. 25]
room.mtype = mtype;           %omnidirectional
room.mic_dist = mic_dist;     
room.mic_center = mic_center; 
room.rel_mic_pos_x = (1:num_mics) * mic_dist - num_mics / 2 * mic_dist - mic_dist / 2;
room.mic_pos = [room.rel_mic_pos_x' + mic_center(1), ones(num_mics, 1) * mic_center(2), ones(num_mics, 1) * mic_center(3)];   
room.source_pos = source_pos; 
room.num_mics = num_mics;      
room.num_sources = 1;         
room.mic_source_dist = norm(room.mic_center - room.source_pos);             
room.mic_source_dist_crit = room.mic_source_dist > room.crit_dist;          

disp('1.2) Computing microphone signals')

%if strcmp(path_source_file,'./soundfiles/female2_16kHz.wav') %'wgn')
if strcmp(path_source_file,'wgn')   
    room.fs = 16e3;  %16000
    room.n_samples = room.fs * room.rt;                         %3200
    room.source_signal = randn(room.n_samples, 1);              
else
    [room.source_signal, room.fs] = audioread(path_source_file); 
    room.n_samples = room.fs * room.rt;
end

room.rirs = rir_generator(room.sound_vel, room.fs, room.mic_pos, room.source_pos, room.room_dim, room.rt, room.n_samples, room.mtype, room.order); 
room.mic_signals = zeros(room.num_mics, size(room.source_signal, 1));

for mic_ind = 1:room.num_mics
    room.mic_signals(mic_ind, :) = fftfilt(room.rirs(mic_ind, :), room.source_signal);     
    room.mic_signals(mic_ind, :) = norm_signal(room.mic_signals(mic_ind, :), 10^(snr/10)); 
    noise_signal = randn(size(room.mic_signals(mic_ind, :)));                              
    noise_signal = norm_signal(noise_signal, 1.0);                                         
    % disp(num2str(compute_snr(room.mic_signals(mic_ind, :), noise_signal)));
    room.mic_signals(mic_ind, :) = room.mic_signals(mic_ind, :) + noise_signal;            
    if write_output
        norm_audiowrite(strcat(path_result_files, 'mic_signal_',num2str(mic_ind),'.wav'), room.mic_signals(mic_ind, :), room.fs)  
    end
end


%% DoA Estimation
disp('2) DoA Estimation')

nfft = 256;
scanning_angle_prec = 1;
scanning_angles = 0:scanning_angle_prec:180; 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% TO INSERT %%%
n_fft_real = nfft/2+1;
n_blocks = floor(size(room.mic_signals, 2) / n_fft_real);

freqs = room.fs * (0:n_fft_real-1) / nfft;
% compute stft for each microphone signal 
mic_signal_stft = zeros(room.num_mics,  n_fft_real,  n_blocks);
for i=1:room.num_mics
    mic_signal_stft(i,:,:) = spectrogram(room.mic_signals(i,:),nfft);
end

% estimate spatial covariance matrix 
cov_est = zeros(n_fft_real, room.num_mics, room.num_mics);
%Rxx = room.mic_signals * room.mic_signals';
for freq = 1:n_fft_real
    cov_est(freq,:,:) = squeeze(mic_signal_stft (:,freq,:)) *squeeze(mic_signal_stft (:,freq,:))';
end
%squeeze(mic_signal_stft (:,freq,:)) *squeeze(mic_signal_stft (:,freq,:))'

% compute music pseudo spectrum
pseudo_spec = zeros(n_fft_real, size(scanning_angles, 2));

d = 0:mic_dist:(num_mics-1)*mic_dist; % Distance between microphones

for freq_ind = 1:n_fft_real
    % compute eigenvalues 
    Rxx = squeeze(cov_est(freq_ind,:,:));
    [EV,D]=eig(Rxx);  % EV eigenvector matrix, D eigenvalues     
   
    % compute noise subspace 
    En = EV(:,room.num_sources+1:end);
   
    for scanning_angle_ind = 1:size(scanning_angles, 2)  % 1~181
        % compute projection of steering vector on noise subspace 
        scanning_angle = scanning_angles(scanning_angle_ind);  % 0 ~ 180
        tt = -d*cos(scanning_angle*pi/180)/sound_vel;
        a = exp(-1j*2*freqs(freq_ind)*pi*tt).';
        pseudo_spec(freq_ind,scanning_angle_ind) = a'*a/(a'*En*En'*a);
    end
end

pseudo_spec = abs(pseudo_spec);
figure(2);
fig_pseudo_spec = imagesc(scanning_angles, freqs, 10*log(pseudo_spec));
colorbar;
title('MUSIC Pseudospectrum')
xlabel('AoA in degree');
ylabel('Frequency in Hz');

if write_output
   saveas(gcf, strcat(path_result_files, 'music_pseudospectrum.png')) 
end

% compute maximum of pseudospectrum
max_doa_angle = zeros(1,n_fft_real);
num_doa = 0; 
sum_doa = 0;
for n = 1:n_fft_real
    if freqs(n) > 500 && freqs(n) < 4000
        max_doa_angle(n) = find( pseudo_spec(n,:)== max(pseudo_spec(n,:)));
        sum_doa = sum_doa + max_doa_angle(n);
        num_doa = num_doa + 1;
    end
end

% average over frequencies to estimate DoA
DoA = sum_doa./num_doa;
room.est_doa = DoA;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Evaluation
disp('3) Evaluation')

room.true_doa = atan2(room.source_pos(2) - room.mic_pos(1, 2), room.source_pos(1) - room.mic_pos(1, 1)) * 180 / pi;
room.error_doa = room.est_doa - room.true_doa;
fprintf('Estimated DoA: %2.2f��\n', room.est_doa)
fprintf('True DoA: %2.2f��\n', room.true_doa)
fprintf('DoA estimation error: %2.2f��\n', room.est_doa - room.true_doa)

%% visualisation of Room
disp('3) Visualizing room')
fig_room = vis_room_2d(room);
if write_output  
  saveas(gcf, strcat(path_result_files, 'room_2d.png'))
end

%% print runtime
runtime = toc(start_sim);
fprintf('Overall runtime: %.2f\n', runtime);
