function [ norm_signal ] = norm_signal(signal, power)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

    norm_signal = signal * sqrt(power / var(signal));
    return;

end

