function [snr] = comp_snr(signal, noise)
%UNTITLED Summary of this function goes here
%   only 1 dimensional

    sig_power = sum(signal.^2) / numel(signal);
    noise_power = sum(noise.^2) / numel(noise);

    snr = 10 * log10(sig_power / noise_power);
    
end

