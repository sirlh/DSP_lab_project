function [ fig ] = vis_room_2d(room)
%% plotting 2-dimensional microphone-sensor configuration
    fig = figure();
    hold on;
    
    xlim([0 room.room_dim(1)]);
    ylim([0 room.room_dim(2)]);
    xlabel('x-axis in m');
    ylabel('y-axis in m');
    
    for mic_ind = 1:room.num_mics
        handle_mic = plot(room.mic_pos(mic_ind,1), room.mic_pos(mic_ind, 2), 'or', 'MarkerSize', 5, 'DisplayName', 'Microphones', 'color', 'r');
    end
    plot([room.mic_pos(1,1) room.mic_pos(end, 1)], [room.mic_pos(1, 2) room.mic_pos(end, 2)], 'DisplayName', 'Microphone Array', 'color', 'r');
    %leg_pl(1) = plot(nan, nan, 'or', 'DisplayName', 'Microphone'); % Nasty workaround

    handle_source = plot(room.source_pos(1), room.source_pos(2), 'ob', 'MarkerSize', 5, 'DisplayName', 'Source');
    %leg_pl(2) = plot(nan, nan, 'ob', 'DisplayName', 'Source'); % Nasty workaround

    
    info_text = strcat('RT60: ', num2str(room.rt), sprintf('s\norder: '), num2str(room.order), sprintf('\nSNR:'), num2str(room.snr, '%2.0f'), sprintf('dB\nTrue DoA: '), num2str(room.true_doa, '%3.0f'), sprintf('\nEst. DoA: '), num2str(room.est_doa, '%3.0f'));
    %info_text = sprintf('Line #1\nThe second line.\nAnd finally a third line.');
    % text(0.075, 0.925 * room.room_dim(2), info_text, 'Parent', gca());
    
    annotation('textbox', [.15 .6 .3 .3], 'String', info_text, 'FitBoxToText','on');
    %legend('Microphone array position', 'Source position');
    legend([handle_mic, handle_source]);
    title('Visualisation of Microphone and Source Positions')
    hold off;
    
end

