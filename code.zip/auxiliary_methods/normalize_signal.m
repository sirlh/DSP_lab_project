function [ norm_signal ] = normalize_signal(signal)

    sig_min = min(signal);
    sig_max = max(signal);

    norm_signal = (signal - sig_min) * 2 / (sig_max - sig_min) - 1;

end

