function norm_audiowrite(filenname, signal, fs)

    norm_signal =  normalize_signal(signal);
    audiowrite(filenname, norm_signal, fs);

end

